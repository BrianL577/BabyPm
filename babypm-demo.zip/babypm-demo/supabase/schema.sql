-- Run this once in the Supabase SQL Editor (Project > SQL Editor > New query > Run).
-- It creates the two tables the demo uses and seeds a small SAMPLE knowledge base.
-- None of the seeded content is real CWW client data — it's clearly-labelled
-- illustrative content so the Knowledge Q&A and Tender Matrix demos have
-- something real to retrieve from. Replace it with real, permissioned CWW
-- artefacts before using this for anything beyond a concept demo.

create extension if not exists "pgcrypto";

create table if not exists babypm_kb_documents (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  doc_type text not null default 'sample',
  content text not null,
  created_at timestamptz not null default now()
);

-- Enables Postgres full-text search via .textSearch() in lib/sample-knowledge.ts
create index if not exists babypm_kb_documents_content_fts
  on babypm_kb_documents
  using gin (to_tsvector('english', content));

create table if not exists babypm_leads (
  id uuid primary key default gen_random_uuid(),
  name text,
  email text not null,
  company text,
  message text,
  created_at timestamptz not null default now()
);

-- Row Level Security: the demo only ever reads/writes via the server-side
-- service role key (see lib/supabase.ts), which bypasses RLS. Enabling RLS
-- with no public policies means these tables are NOT reachable from a
-- browser using the public anon key, even if that key were ever exposed.
alter table babypm_kb_documents enable row level security;
alter table babypm_leads enable row level security;

insert into babypm_kb_documents (title, doc_type, content) values
(
  'Sample Weekly Status Report Template',
  'sample_report',
  'Project: Sample Council — Finance System Replacement (illustrative example)
Reporting period: Week ending [date]

Executive summary: Delivery is broadly on track. Data migration dry-run #2 completed with a 94% match rate against source records, against a 98% target before go-live.

Delivery confidence: AMBER — on track for the milestone date, but the migration match-rate gap and one outstanding vendor dependency need to close within two weeks to hold GREEN.

Milestones this period: UAT test pack signed off; migration dry-run #2 complete.
Upcoming milestones: Migration dry-run #3 (target 98% match); training material sign-off.

Risks: Match-rate shortfall could push go-live if not resolved by dry-run #3.
Issues: One integration vendor has not yet confirmed test environment availability.
Dependencies: Client finance team sign-off on reconciliation approach.
Recommended actions: Escalate vendor environment dependency to steering committee; schedule a focused data-quality working session before dry-run #3.'
),
(
  'Sample Case Study — Local Government ERP Rollout',
  'sample_case_study',
  'Client type: Local government authority (illustrative example, anonymised)
Engagement: Programme advisory and test management for an ERP replacement covering finance, payroll and procurement.

Approach: Established a governance cadence (steering committee, RAG-rated weekly reporting, risk and issue register), ran an independent test management function across SIT, UAT and cutover rehearsal, and produced executive-ready status reporting throughout.

Outcome: Programme delivered with two cutover rehearsals reducing go-live defects materially versus the authority''s prior major system implementation.

Relevant services: Program and project advisory, test management, governance design, executive reporting.'
),
(
  'Sample Case Study — Healthcare System Data Migration Readiness',
  'sample_case_study',
  'Client type: Healthcare provider (illustrative example, anonymised)
Engagement: Data migration readiness assessment and cutover planning advisory ahead of a clinical systems consolidation.

Approach: Ran a readiness assessment against migration, testing and cutover-planning criteria, identified gaps in data quality ownership, and built a cutover runbook with rollback triggers and go/no-go criteria for executive sign-off.

Outcome: Go/no-go criteria were adopted as the standard cutover governance artefact for two subsequent phases of the programme.

Relevant services: Data migration readiness, cutover planning, business analysis, change management.'
),
(
  'CWW Service Overview — Program and Project Advisory',
  'service_description',
  'CWW Project Delivery provides program and project advisory, project services, test management, business analysis, change management and project administration, across industries including local government and healthcare.

CWW''s value is grounded in practical delivery experience, advisory judgement, governance discipline and executive communication — identifying risks, gaps and required actions across complex implementation programs, while leaving final professional judgement with the Principal Consultant.'
);
